# GitTool
Git Best Tools Hacking For Kali Linux 2018

### Download&install

### gitclone https://github.com/Ha3MrX/GitTool

### cd GitTool

### chmod +x gittool.sh

### ./gittool.sh

### ScreenShot 

![capture](https://user-images.githubusercontent.com/33704360/39895179-fb2741c4-54b1-11e8-9a75-5a27b07cf064.PNG)

### Youtube channel

### https://www.youtube.com/c/HA-MRX

### Viddeo Tutorial

### https://www.youtube.com/watch?v=APkZOXJ2rnk
